//
//  YYYGameplug.h
//  YYYGameplug
//
//  Created by Ning Fu on 2021/5/29.
//  Copyright © 2021 Ning Fu. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for YYYGameplug.
FOUNDATION_EXPORT double YYYGameplugVersionNumber;

//! Project version string for YYYGameplug.
FOUNDATION_EXPORT const unsigned char YYYGameplugVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <YYYGameplug/PublicHeader.h>


